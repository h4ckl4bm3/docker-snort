--[[
# Copyright (C) Cisco and/or its affiliates. All rights reserved.
# Copyright 2001-2013 Sourcefire, Inc. All Rights Reserved.
#
# This file contains detector content that was created,
# tested, and certified by Sourcefire, Inc. that is
# distributed under the OpenAppID Detector Content License
# Agreement (v 1.0).
#
# The detector content is owned by Sourcefire, Inc.
#
# Please refer to the OpenAppID Detector Content License
# Agreement (v1.0) for details.
--]]
--[[
detection_name: Kazaa
description: Peer-to-peer software.
--]]

require "DetectorCommon"


local DC = DetectorCommon

DetectorPackageInfo = {
    name =  "Kazaa",
    proto =  DC.ipproto.tcp,
    client = {
        init =  'DetectorInit',
        clean =  'DetectorClean',
        validate =  'DetectorValidator',
        minimum_matches =  1
    }
}

function DetectorClean()
end

function DetectorInit(detectorInstance)
    gDetector = detectorInstance
    gDetector:addHttpPattern(1, 0, 0, 57, 15, 0, 0, 'kazaa', 699, 1);
    return gDetector
end

function DetectorValidator()
    local context = {}
    return clientFail(context)
end

function DetectorFini()
end
